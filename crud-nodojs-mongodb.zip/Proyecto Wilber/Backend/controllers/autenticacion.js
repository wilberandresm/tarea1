'use strict'

const Reserva = require('../models/reserva');
const XMLHttpRequest = require('xmlhttprequest').XMLHttpRequest;
const fetch = require('node-fetch');

const controller = {

    Autenticacion: function (req, res) {
        const params = req.body;
        const url = "http://savio.utbvirtual.edu.co/login/token.php?username="+params.usuario+"&password="+params.contraseña+"&service=moodle_mobile_app";
        fetch(url)
        .then(function(data) {
            res.status(200).send(data);
        })
   
    },


};

module.exports = controller;
