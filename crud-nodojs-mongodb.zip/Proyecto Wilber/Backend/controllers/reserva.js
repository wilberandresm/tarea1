'use strict'

const mongoose = require('mongoose');
const Reserva = require('../models/reserva');

const controller = {


    createReserva: function (req, res) {
        const reserva = new Reserva();
        const params = req.body;
        reserva.usuario = params.usuario;
        reserva.sala = params.sala;
        reserva.hora = params.hora;
        reserva.save((err, reservaStored) => {
            if (err) return res.status(500).send({ message: 'Error' });
            if (!reservaStored) return res.status(404).send({message: 'No se puede realizar la reserva'});
            return res.status(200).send({ list: reservaStored});
        });
    },


    getReservas: function (req, res) {
        Reserva.find({}).exec((err, reservas) => {
            if (err) return res.status(500).send({ message: 'Error' });
            if (!reservas) return res.status(404).send({ message: 'No hay reservas que mostrar' });
            return res.status(200).send({ reservas });
        });
    },

    deleteReserva: function (req,res) {
        const idReserva = req.params.id;
        Reserva.findOneAndDelete(idReserva, (err,reservaDeleted) => {
            if (err) return res.status(500).send({ message: 'No se puede eliminar la reserva' });
            if (!reservaDeleted) return res.status(404).send({ message: 'No se encuentra esta reserva' });
            return res.status(200).send({reserva: reservaDeleted});
        });
    }

};

module.exports = controller;
