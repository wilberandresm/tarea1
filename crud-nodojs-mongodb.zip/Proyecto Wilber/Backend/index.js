'use strict'

const mongoose = require('mongoose');
const app = require('./app');
const port = 3700;

mongoose.Promise = global.Promise;
mongoose.set('useFindAndModify', false);
mongoose.connect("mongodb://localhost:27017/reservas", { useNewUrlParser: true }).then(
    () => {
        console.log("Connection to the database successfully established");
        app.listen(port, ()=> {
            console.log("Server running correctly in the url: localhost: 3700")
        });
      },
      err => {
        console.log("Error connecting Database instance due to: ", err);
      }
);