'use strict'

const express = require('express');
const AutenticacionController = require('../controllers/autenticacion');
const router = express.Router();

router.post('/login', AutenticacionController.Autenticacion);

module.exports = router;