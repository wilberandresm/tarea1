'use strict'

const express = require('express');
const ReservaController = require('../controllers/reserva');
const router = express.Router();

router.post('/crear', ReservaController.createReserva);
router.get('/reservas', ReservaController.getReservas);
router.delete('/eliminar/:id', ReservaController.deleteReserva);

module.exports = router;