'use strict'

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ReservaSchema = Schema({
    usuario: {type:String, required: true},
    sala: {type:String, required: true},
    hora: {type:String, required: true}
});

module.exports = mongoose.model('Reseva', ReservaSchema);